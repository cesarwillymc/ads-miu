public interface Iterator<T> {
    T getNext();

    Boolean hasMore();
}
