import java.util.Vector;

public interface UpdateChanges {
    void notifyList(Vector<String> vector);
}
