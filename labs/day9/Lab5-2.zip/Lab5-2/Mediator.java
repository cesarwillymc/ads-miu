import java.util.Vector;

public interface Mediator {
    void updateView();

    void setTextPush(String command);
}
