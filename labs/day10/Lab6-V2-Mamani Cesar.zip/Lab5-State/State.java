public interface State {
    void checkSpeed();
    String getShift();
}
