public class Car {
    private State currentState;
    private int speed;

    public void changeState(State speed) {
        currentState = speed;
    }
    public void changeSpeed(int speed) {
        this.speed = speed;
        currentState.changeSpeed();
    }

    public Car() {
        this.currentState = new ParkState(this);
    }

    public State getCurrentState() {
        return currentState;
    }

    public int getSpeed() {
        return speed;
    }
}
    
