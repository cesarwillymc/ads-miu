public interface State {
    void changeSpeed();
    String getShift();
}
