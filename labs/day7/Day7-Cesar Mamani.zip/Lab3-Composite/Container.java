public interface Container {
    double computePrice();

    double netPrice();

    double discountPrice();
}
