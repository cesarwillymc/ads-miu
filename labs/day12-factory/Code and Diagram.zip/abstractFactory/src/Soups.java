import java.util.List;

public interface Soups {
    List<Food> createMenu();
}
