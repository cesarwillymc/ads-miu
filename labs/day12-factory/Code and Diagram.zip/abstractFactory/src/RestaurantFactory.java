public interface RestaurantFactory {
    Sandwiches createSandwiches();
    Soups createSoups();
}
