import java.util.List;

public interface Sandwiches {
    List<Food> createMenu();
}
