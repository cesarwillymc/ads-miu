package part1.usignOwnLibrary2.Observer;

public interface Observer<T> {
    void update(T data);
}
