package part1.usingOwnLibrary1.Observer;

public interface Observer {
    void update();
}
