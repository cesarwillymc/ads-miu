package part2;

public interface Observer<T> {
    void update(T data);
}
