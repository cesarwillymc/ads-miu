package generic;

public interface Thing<T> {

    void compute(  T input);
}
