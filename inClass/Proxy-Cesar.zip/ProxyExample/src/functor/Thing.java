package functor;

public interface Thing {

    void compute(String input);
}
