package functor;

public interface Functor {

    void pre();

    void post();

}
