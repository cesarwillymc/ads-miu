package proxy;

public interface Thing {
    void compute(String message);
}
